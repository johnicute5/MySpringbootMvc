package bizz.global77.model;

import javax.persistence.*;
import javax.validation.constraints.Pattern;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

import java.io.Serializable;

@Entity
@Table(name = "learner")
public class Learner implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GenericGenerator(name = "generator", strategy = "increment")
	@GeneratedValue(generator = "generator",strategy = GenerationType.IDENTITY)
	@Column(name="id" )
	private Long id;

	@NotEmpty(message = "Name must not be empty")
	@NotBlank(message = "Name must not be blank")
	@Column(name="learner_name")
	private String learnerName;

	@Length(min = 7, max = 7, message = "Employee Id must be 7 characters")
	@NotEmpty(message = "Employee Id must not be empty")
	@NotBlank(message = "EmEmployee Id must not be empty must not be blank")
	@Column(name="employee_id")
	private String employeeId;

	@Range(min = 18, max = 99, message = "Age must be 18 and below 100")
	@Column(name="age")
	private Integer age;

	@Pattern(message = "Invalid email format",regexp = ".+@.+\\.[a-z]+")
	@NotEmpty(message = "Email must not be empty")
	@Column(name="email_id")
	private String emailId;

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Learner() {

	}

	public String getLearnerName() {
		return learnerName;
	}

	public void setLearnerName(String learnerName) {
		this.learnerName = learnerName;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Learner(String lName, String empId, Integer age, String emailId) {
		this.learnerName = lName;
		this.employeeId = empId;
		this.age = age;
		this.emailId = emailId;
	}
}
