package bizz.global77.model;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.*;
import javax.persistence.*;


@Entity
@Table(name = "learner_course")
public class LearnerCourse {
    @Id
    @GenericGenerator(name = "generator", strategy = "increment")
    @GeneratedValue(generator = "generator", strategy = GenerationType.IDENTITY)
    @Column(name = "course_id")
    private Long id;

    @NotEmpty(message = "Course must not be empty")
    @NotBlank(message = "Course must not be blank")
    @Column(name = "course_title")
    private String courseTitle;

    @Range(min = 1, max = 12, message = "Error! Course cannot be lesser than 1 and greater than 12!")
    @Column(name = "unit")
    private Integer unit;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LearnerCourse() {

    }

    public LearnerCourse(String courseTitle, Integer unit) {

        this.courseTitle = courseTitle;
        this.unit = unit;
    }
    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public Integer getUnit() {
        return unit;
    }

    public void setUnit(Integer unit) {
        this.unit = unit;
    }

}
