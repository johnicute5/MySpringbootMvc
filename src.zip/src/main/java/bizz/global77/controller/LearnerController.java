package bizz.global77.controller;

import java.util.List;

import javax.validation.Valid;

import bizz.global77.model.LearnerCourse;
import bizz.global77.repository.LearnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import bizz.global77.model.Learner;


@Controller
public class LearnerController {
	@Autowired
	LearnerRepository learnerRepository;

	@RequestMapping(value = "/learner", method = RequestMethod.GET)
	public ModelAndView showForm() {
		return new ModelAndView("enrol", "learnerForm", new Learner());
	}

	@RequestMapping(value = "/learnerAction", method = RequestMethod.POST)
	public String submit(@Valid @ModelAttribute("learnerForm") Learner learner, BindingResult result, ModelMap model) {
		System.out.println(result);
		if (result.hasErrors()) {
			model.addAttribute("error", result);
			return "enrol";
		}
		learnerRepository.save(learner);
		String message = "We welcome you.. " + learner.getLearnerName();
		// add message to model
		model.addAttribute("message", message);
		model.addAttribute("learnerName", learner.getLearnerName());
		model.addAttribute("employeeId", learner.getEmployeeId());
		model.addAttribute("age", learner.getAge());
		model.addAttribute("emailId", learner.getEmailId());

		return "acknowledge";

	}

	@RequestMapping(value = "/listlearner")
	public String listEmployee(@Valid @ModelAttribute("listLearner") Learner learner, BindingResult result,
			ModelMap model) {
		List<Learner> mylistLearner = learnerRepository.findAll();
		model.addAttribute("mylistLearner", mylistLearner);
		return "listlearner";
	}
	@GetMapping("/dellistlearner")
	public String delete(@RequestParam Long learnerId) {
		learnerRepository.deleteById(learnerId);
		return "redirect:/listlearner";
	}



}
