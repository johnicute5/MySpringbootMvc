package bizz.global77.controller;

import bizz.global77.model.LearnerCourse;
import bizz.global77.repository.LearnerCourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;


@Controller
public class LearnerCourseController {
    @Autowired
    LearnerCourseRepository learnerCourseRepository;

    @RequestMapping(value = "/addcourse", method = RequestMethod.GET)
    public ModelAndView showCourseForm() {
        return new ModelAndView("addcourse", "learnerCourseForm", new LearnerCourse());
    }
    @RequestMapping(value = "/learnercourseAction", method = RequestMethod.POST)
    public String submitCourse(@Valid @ModelAttribute("learnerCourseForm") LearnerCourse learnerCourse, BindingResult result, ModelMap model) {
        System.out.println(result);
        if (result.hasErrors()) {
            model.addAttribute("error", result);
            return "addcourse";
        }
        learnerCourseRepository.save(learnerCourse);
        String message = "Successfully Added.. " + learnerCourse.getCourseTitle();
        // add message to model
        model.addAttribute("message", message);
        model.addAttribute("courseTitle", learnerCourse.getCourseTitle());
        model.addAttribute("unit", learnerCourse.getUnit());
        return "courseacknowledge";

    }

    @RequestMapping(value = "/listlearnercourse")
    public String listEmployee(@Valid @ModelAttribute("listlearnercourse") LearnerCourse learnerCourse,BindingResult result,
                               ModelMap model) {
        List<LearnerCourse> mylistLearnerCourse = learnerCourseRepository.findAll();
        model.addAttribute("mylistLearnerCourse", mylistLearnerCourse);
        return "listlearnercourse";
    }

    @GetMapping("/dellistlearnercourse")
    public String delete(@RequestParam Long learnerCourseId) {
        learnerCourseRepository.deleteById(learnerCourseId);
        return "redirect:/listlearnercourse";
    }


}
