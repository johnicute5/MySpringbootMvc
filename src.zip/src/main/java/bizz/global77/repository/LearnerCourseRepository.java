package bizz.global77.repository;

import bizz.global77.model.LearnerCourse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Repository
@Service
public interface LearnerCourseRepository extends JpaRepository<LearnerCourse,Long> {
}
